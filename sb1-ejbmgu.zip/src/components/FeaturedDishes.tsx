const dishes = [
  {
    id: 1,
    name: "Grilled Salmon",
    description: "Fresh Atlantic salmon with herbs and lemon",
    price: "$24.99",
    image: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=500&q=80"
  },
  {
    id: 2,
    name: "Truffle Pasta",
    description: "Handmade pasta with black truffle sauce",
    price: "$19.99",
    image: "https://images.unsplash.com/photo-1473093226795-af9932fe5856?w=500&q=80"
  },
  {
    id: 3,
    name: "Wagyu Steak",
    description: "Premium Japanese Wagyu A5 grade",
    price: "$89.99",
    image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=500&q=80"
  }
];

export default function FeaturedDishes() {
  return (
    <section id="menu" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-bold text-center mb-12">Featured Dishes</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {dishes.map((dish) => (
            <div key={dish.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
              <img 
                src={dish.image} 
                alt={dish.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{dish.name}</h3>
                <p className="text-gray-600 mb-4">{dish.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-orange-600">{dish.price}</span>
                  <button className="bg-orange-600 text-white px-4 py-2 rounded hover:bg-orange-700">
                    Order Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}