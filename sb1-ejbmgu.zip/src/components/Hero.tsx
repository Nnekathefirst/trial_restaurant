export default function Hero() {
  return (
    <div className="relative h-screen bg-gradient-to-r from-orange-100 to-orange-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
        <div className="w-full md:w-1/2 space-y-8">
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900">
            Discover the Art of <span className="text-orange-600">Fine Dining</span>
          </h1>
          <p className="text-xl text-gray-600">
            Experience culinary excellence with our handcrafted dishes made from the finest ingredients.
          </p>
          <div className="space-x-4">
            <button className="bg-orange-600 text-white px-8 py-3 rounded-lg text-lg hover:bg-orange-700">
              View Menu
            </button>
            <button className="border-2 border-orange-600 text-orange-600 px-8 py-3 rounded-lg text-lg hover:bg-orange-50">
              Book Table
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}